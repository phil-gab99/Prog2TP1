/**
* @author Philippe Gabriel
* @version 1.0 2020-11-12
*
* The class Main begins the application
***/

public class Main {

    public static void main(String[] args) {

        mvc.StoreView.run();
    }
}